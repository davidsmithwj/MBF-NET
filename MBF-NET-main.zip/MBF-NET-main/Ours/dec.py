import torch
import torch.nn as nn
import torch.nn.functional as F
from Base_transformer import point_dec

# 使用 point_dec 的值
value = point_dec
print(value)
